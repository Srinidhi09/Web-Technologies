package com.connect;

import java.sql.Connection;
import java.sql.DriverManager;
public class dbConnect
{
public static Connection getConnect()
{
  try
    {
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/bank","root","root");
        return con;
    }catch(Exception e)
    {
        System.out.println("exception is "+e);
        return null;
    }
    
}
}
